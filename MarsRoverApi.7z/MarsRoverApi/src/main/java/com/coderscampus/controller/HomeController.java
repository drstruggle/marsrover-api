package com.coderscampus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.coderscampus.dto.HomeDto;
import com.coderscampus.dto.HomeDtoInitializer;
import com.coderscampus.entity.MarsRoverApiResponse;
import com.coderscampus.service.MarsRoverApiService;

@Controller
public class HomeController {

	@Autowired
	private MarsRoverApiService apiService;
	
	@Autowired
	private HomeDtoInitializer homeDtoInitializer;
	
	@RequestMapping(value="/", method= {RequestMethod.GET, RequestMethod.POST})
	public String postHome(Model model, HomeDto homeDto) {

	//add the camera's and rovers, so that all buttons display
	model.addAttribute("allCameras", homeDtoInitializer.getAllCameras());
	model.addAttribute("allRovers", homeDtoInitializer.getAllRovers());

	//make sure that all values are either filled, or give them defaults
	if (homeDto.getRoverName()==null) {homeDto.setRoverName(homeDtoInitializer.getRoverName());}
	if (homeDto.getSol()==null) {homeDto.setSol(homeDtoInitializer.getSol());}
	if (homeDto.getCamera()==null) {homeDto.setCamera(homeDtoInitializer.getCamera());}
	model.addAttribute("homeDto", homeDto);
	
	//get and add the data
	MarsRoverApiResponse marsRoverData=apiService.getMarsRoverData(homeDto);
	model.addAttribute("marsRoverData", marsRoverData);
	
	return "index";
	}
}
	
	
	
	
	
	




























