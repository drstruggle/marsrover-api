package com.coderscampus.dto;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class HomeDto {

	private String roverName;

	private String sol;

	private String[]camera;

	public HomeDto() {}
	
	public HomeDto(String roverName,String sol, String[] camera) {
        			this.roverName=roverName;
        			this.sol=sol;
        			this.camera=camera;
    }

	public String getRoverName() {
		return roverName;
	}

	public void setRoverName(String roverName) {
		this.roverName = roverName;
	}

	public String getSol() {
		return sol;
	}

	public void setSol(String sol) {
		this.sol = sol;
	}

	public String[] getCamera() {
		return camera;
	}

	public void setCamera(String[] camera) {
		this.camera = camera;
	}

	
}
