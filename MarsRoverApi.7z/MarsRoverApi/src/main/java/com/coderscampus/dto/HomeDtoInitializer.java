package com.coderscampus.dto;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class HomeDtoInitializer {

	@Value("${NASA.api.baseurl}")
	private String baseUrl;

	@Value("${nasa.api.key}")
	private String key;

	@Value("${NASA.api.collection.roverName}")
	public String[] allRovers;

	@Value("#{${NASA.api.collection.camera}}")
	public Map<String,String> allCameras;

	@Value("${NASA.api.initial.roverName}")
	private String roverName;

	@Value("${NASA.api.initial.sol}")
	private String sol;

	@Value("${NASA.api.initial.camera}")
	private String[]camera;
	
	public HomeDtoInitializer() {}
	
	public HomeDto initClass() {
        return new HomeDto(this.roverName, this.sol, this.camera);
    }
	
	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String[] getAllRovers() {
		return allRovers;
	}

	public void setAllRovers(String[] allRovers) {
		this.allRovers = allRovers;
	}

	public Map<String,String> getAllCameras() {
		return allCameras;
	}

	public void setAllCameras(Map<String,String> allCameras) {
		this.allCameras = allCameras;
	}

	public String getRoverName() {
		return roverName;
	}

	public void setRoverName(String roverName) {
		this.roverName = roverName;
	}

	public String getSol() {
		return sol;
	}

	public void setSol(String sol) {
		this.sol = sol;
	}


	public String[] getCamera() {
		return camera;
	}

	public void setCamera(String[] camera) {
		this.camera = camera;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
