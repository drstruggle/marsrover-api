package com.coderscampus.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.coderscampus.dto.HomeDto;
import com.coderscampus.dto.HomeDtoInitializer;
import com.coderscampus.entity.MarsRoverApiResponse;
import com.coderscampus.entity.Photo;

@Service
public class MarsRoverApiService {

	@Autowired
	private HomeDtoInitializer homeDtoInitializer;

	public MarsRoverApiResponse getMarsRoverData(HomeDto homeDto) {


		//get response/photo's for every requested camera
		List<Photo>retrievedPhotos=new ArrayList<>();
		MarsRoverApiResponse response= new MarsRoverApiResponse();
		
		//get API DATA via RESTTEMPLATE
		RestTemplate template= new RestTemplate();
		for(String cam: homeDto.getCamera()) {
			ResponseEntity<MarsRoverApiResponse> responseEntity;
			responseEntity= template.getForEntity(composeUrl(homeDto.getRoverName(), 
					homeDto.getSol(), cam), MarsRoverApiResponse.class);
			retrievedPhotos.addAll(responseEntity.getBody().getPhotos());
		}

//		//get API DATA via WEBCLIENT - DOESN'T WORK
//		
//		for(String cam: homeDto.getCamera()) {
//			response = WebClient.create()
//								.get()
//							 	.uri(composeUrl(homeDto.getRoverName(), homeDto.getSol(), cam))
//							 	.retrieve()
//							 	.bodyToMono(MarsRoverApiResponse.class)
//								.block();
//			retrievedPhotos.addAll(response.getPhotos());
//		}

		
		//cumulate all API DATA/photo results in one response
		response.setPhotos(retrievedPhotos);
		
		return response;
	}

	public String composeUrl(String roverName, String sol, String cam) {

		//generate searchstring for rover, sol and ONE camera
		String searchUrl= homeDtoInitializer.getBaseUrl()
		+ roverName 
		+ "/photos?sol="+sol
		+ "&camera="+cam
		+ "&api_key="+homeDtoInitializer.getKey();

		//check via console
		System.out.println(searchUrl);
		
		return searchUrl;
	}

	
	
}



























