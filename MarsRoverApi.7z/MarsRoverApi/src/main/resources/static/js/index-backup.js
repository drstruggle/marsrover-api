
//submit form when buttonrovername is pressed
let roverButtons=document.querySelectorAll("button[id*='buttonRoverName']");

roverButtons.forEach( button => button.addEventListener('click', function(){
								const buttonId = this.id;
								const roverId = buttonId.split('buttonRoverName')[1];
								let roverButton = document.getElementById('roverName');
								roverButton.value = roverId;
								document.getElementById('frmRoverName').submit();
								}))

// repaint button based on url
let requestedRoverName = getUrlParameter("roverName");
highLightRoverName(requestedRoverName);


// prefil sol 

let requestedSol = getUrlParameter("sol");
if (requestedSol==''){requestedSol='100'}
document.getElementById('sol').value=requestedSol;


// functions

function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}

function highLightRoverName(rover){
  if (rover==''){rover='Curiosity'}

  document.getElementById("buttonRoverName"+rover).classList.remove("btn-secondary");
  document.getElementById("buttonRoverName"+rover).classList.add("btn-primary");
}























