package com.coderscampus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarsRoverApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
