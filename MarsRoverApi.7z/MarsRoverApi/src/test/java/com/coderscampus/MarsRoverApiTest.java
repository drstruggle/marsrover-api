package com.coderscampus;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.client.RestTemplate;

import com.coderscampus.entity.MarsRoverApiResponse;

public class MarsRoverApiTest {

	@Test
	public void smallTest() {
	
	RestTemplate template= new RestTemplate();
	
	String url="https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=1&api_key=DEMO_KEY";
	ResponseEntity<MarsRoverApiResponse> response= template.getForEntity(url, MarsRoverApiResponse.class);
	
	System.out.println(response.getBody());
	
	}
		
}













