package com.coderscampus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.coderscampus.dto.SearchDto;
import com.coderscampus.entity.MarsRoverApiResponse;
import com.coderscampus.service.MarsRoverInitService;
import com.coderscampus.service.MarsRoverApiService;

@Controller
public class HomeController {

	@Autowired
	private MarsRoverApiService marsRoverApiService;
	
	@Autowired
	private MarsRoverInitService marsRoverInitService;
	
	@RequestMapping(value="/", method= {RequestMethod.GET, RequestMethod.POST})
	public String homePage(Model model, SearchDto searchDto) {

	//make sure that all values are either filled, or give them defaults
	if (searchDto.getRoverName()==null) {searchDto.setRoverName(marsRoverInitService.getRoverName());}
	if (searchDto.getSol()==null) {searchDto.setSol(marsRoverInitService.getSol());}
	if (searchDto.getCamera()==null) {searchDto.setCamera(marsRoverInitService.getCamera());}
	model.addAttribute("searchDto", searchDto);

	//get and add the data
	MarsRoverApiResponse marsRoverData=marsRoverApiService.getMarsRoverData(searchDto);
	model.addAttribute("marsRoverData", marsRoverData);

	//add the camera's and rovers, so that all buttons display
	model.addAttribute("allCameras", marsRoverInitService.getAllRoverCameras(searchDto.getRoverName()));
	model.addAttribute("allRovers", marsRoverInitService.getAllRovers());

	return "index";
	}
}
	
	
	
	
	
	




























