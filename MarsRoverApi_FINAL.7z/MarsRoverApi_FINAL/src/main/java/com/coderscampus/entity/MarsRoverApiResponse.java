package com.coderscampus.entity;

import java.util.ArrayList;
import java.util.List;

public class MarsRoverApiResponse {

	List<Photo>photos=new ArrayList<>();
	
	public MarsRoverApiResponse() {}

	public List<Photo> getPhotos() {
		return photos;
	}

	public void setPhotos(List<Photo> photos) {
		this.photos = photos;
	}
	
	public void deletePhoto(int element) {
		this.photos.remove(element);
	}
	
	@Override
	public String toString() {
		return "MarsRoverApiResponse [photos=" + photos + "]";
	}
	
	
	
}
