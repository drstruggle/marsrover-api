package com.coderscampus.entity;

public class RoverCamera {

	private String camera;
	private String description;
	private Boolean enabled;
	
	
	public RoverCamera(String camera, String description, Boolean enabled) {
		this.camera = camera;
		this.description = description;
		this.enabled = enabled;
	}
	
	public String getCamera() {
		return camera;
	}
	public void setCamera(String camera) {
		this.camera = camera;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getEnabled() {
		return enabled;
	}
	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "RoverCamera [camera=" + camera + ", description=" + description + ", enabled=" + enabled + "]";
	}

	
	
	
}
