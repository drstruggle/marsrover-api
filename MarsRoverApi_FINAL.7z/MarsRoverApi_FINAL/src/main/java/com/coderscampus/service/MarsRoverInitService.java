package com.coderscampus.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.coderscampus.dto.SearchDto;
import com.coderscampus.entity.RoverCamera;

@Service
public class MarsRoverInitService {

	@Value("${NASA.api.baseurl}")
	private String baseUrl;

	@Value("${nasa.api.key}")
	private String key;

	@Value("${NASA.api.all.rovers}")
	public String[] allRovers;

	@Value("#{${NASA.api.all.cameras}}")
	public Map<String,String> allCameras;

	@Value("#{${NASA.api.all.rovercameras}}")
	public Map<String,String> allRoverCameras;
	
	@Value("${NASA.api.initial.roverName}")
	private String roverName;

	@Value("${NASA.api.initial.sol}")
	private String sol;

	@Value("${NASA.api.initial.camera}")
	private String[]camera;
	
	public MarsRoverInitService() {}
	
	public SearchDto initClass() {
        return new SearchDto(this.roverName, this.sol, this.camera);
    }
	
	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String[] getAllRovers() {
		return allRovers;
	}

	public void setAllRovers(String[] allRovers) {
		this.allRovers = allRovers;
	}

	public Map<String,String> getAllCameras() {
		return allCameras;
	}

	public void setAllCameras(Map<String,String> allCameras) {
		this.allCameras = allCameras;
	}

	public Map<String, String> getAllRoverCameras() {
		return allRoverCameras;
	}

	public List<RoverCamera> getAllRoverCameras(String rover) {
		
		List<RoverCamera> rCL = new ArrayList<>();
		Map<String, String> aCaDe= getAllCameras();
		String rCS = allRoverCameras.get(rover);
		
		for (Map.Entry<String,String> entry : aCaDe.entrySet()) {  
			rCL.add(new RoverCamera(entry.getKey(),	entry.getValue(),rCS.indexOf(entry.getKey())==-1));
		}
		return rCL;
	}

	public void setAllRoverCameras(Map<String, String> roverCameras) {
		this.allRoverCameras = roverCameras;
	}

	public String getRoverName() {
		return roverName;
	}

	public void setRoverName(String roverName) {
		this.roverName = roverName;
	}

	public String getSol() {
		return sol;
	}

	public void setSol(String sol) {
		this.sol = sol;
	}


	public String[] getCamera() {
		return camera;
	}

	public void setCamera(String[] camera) {
		this.camera = camera;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
